// Simple client-side simulation of the 5-level access model.
// Level 5 sees everything. Level 4 sees everything at their own station.
// Level 3 sees cases where they are the investigating officer.
// Level 1-2 must request access unless separately assigned.
// External roles (judge/forensic) are eligible only if explicitly assigned.

export function isEligible(officer, caseItem) {
  if (!officer) return false

  if (officer.access_level === 5) return true

  if (officer.access_level === 4) {
    return caseItem.station_name === officer.station
  }

  if (officer.access_level === 3) {
    return caseItem.investigating_officer.includes(officer.officer_id)
  }

  if (officer.access_level === 2 || officer.access_level === 1) {
    return caseItem.assisting_officer.includes(officer.officer_id)
  }

  // External roles (judge / forensic) — eligible only if explicitly assigned
  if (typeof officer.access_level === 'string') {
    return (caseItem.external_assignments || []).some((a) =>
      a.includes(officer.officer_id)
    )
  }

  return false
}

export function accessLevelLabel(level) {
  if (level === 5) return 'Level 5 — Full Access'
  if (level === 4) return 'Level 4 — Station Access'
  if (level === 3) return 'Level 3 — Case Access'
  if (level === 2) return 'Level 2 — Limited Access'
  if (level === 1) return 'Level 1 — Restricted'
  return 'External — Assigned Access'
}

export function accessBadgeClass(level) {
  if (level === 5) return 'badge-gold'
  if (level === 4) return 'badge-teal'
  if (level === 3) return 'badge-slate'
  if (level === 2 || level === 1) return 'badge-rust'
  return 'badge-slate'
}
