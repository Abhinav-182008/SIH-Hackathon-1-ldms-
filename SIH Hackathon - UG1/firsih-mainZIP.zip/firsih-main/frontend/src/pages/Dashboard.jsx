import React from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext.jsx'
import TopBar from '../components/TopBar.jsx'
import './Dashboard.css'

export default function Dashboard() {
  const { officer } = useAuth()
  const navigate = useNavigate()

  const firstName = officer.name.split(' ')[0]

  return (
    <div>
      <TopBar />
      <div className="dash-wrap">
        <div className="dash-greeting">
          <div className="eyebrow">{officer.station || 'External Assignment'}</div>
          <h1>Welcome back, {firstName}.</h1>
          <p>
            Choose what you'd like to do. Every action you take here — uploads,
            searches, and access requests — is recorded in the case audit log.
          </p>
        </div>

        <div className="option-grid">
          <button className="option-card" onClick={() => navigate('/add-record')}>
            <div className="option-icon add">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                <path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V9l-5-6Z" stroke="currentColor" strokeWidth="1.6"/>
                <path d="M14 3v6h5" stroke="currentColor" strokeWidth="1.6"/>
                <path d="M12 13v6M9 16h6" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"/>
              </svg>
            </div>
            <h3>Add Record</h3>
            <p>
              Create a new case or add a document to an existing one. Files are
              read, indexed, and encrypted automatically on upload.
            </p>
            <span className="go">Open →</span>
          </button>

          <button className="option-card" onClick={() => navigate('/search-record')}>
            <div className="option-icon search">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                <circle cx="11" cy="11" r="7" stroke="currentColor" strokeWidth="1.6"/>
                <path d="m20 20-3.5-3.5" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"/>
              </svg>
            </div>
            <h3>Search Record</h3>
            <p>
              Ask a plain-language question across every case you're permitted
              to see. Original files still require the right clearance to open.
            </p>
            <span className="go">Open →</span>
          </button>
        </div>

        <div className="dash-station-note">
          <span className="mono" style={{ color: 'var(--text-muted)' }}>ⓘ</span>
          <span>
            Signed in as <strong>{officer.rank}</strong>
            {officer.station ? <> at <strong>{officer.station}</strong></> : null}.
            Your search results and file access are limited to what your
            clearance allows.
          </span>
        </div>
      </div>
    </div>
  )
}
