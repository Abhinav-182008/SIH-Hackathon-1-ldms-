import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext.jsx'
import officers from '../data/officers.json'
import stations from '../data/stations.json'
import cases from '../data/cases_manifest.json'
import credentials from '../data/credentials.json'
import './Login.css'

export default function Login() {
  const { login, error } = useAuth()
  const navigate = useNavigate()

  const [loginId, setLoginId] = useState('')
  const [password, setPassword] = useState('')
  const [showCreds, setShowCreds] = useState(false)

  function handleSubmit(e) {
    e.preventDefault()
    const ok = login(loginId, password)
    if (ok) navigate('/dashboard')
  }

  return (
    <div className="login-screen">
      <div className="login-brand">
        <div className="login-mark">
          <div className="login-mark-glyph">CV</div>
          <div>
            <div className="login-mark-name">CaseVault</div>
            <div className="login-mark-sub">Secure Case File System</div>
          </div>
        </div>

        <div className="login-headline">
          <h1 className="login-title">
            <span className="fir-big">FIR</span>
            <span className="management-small">Management</span>
          </h1>
        </div>

        <div className="login-stats">
          <div>
            <div className="login-stat-value">{cases.length}</div>
            <div className="login-stat-label">Active cases</div>
          </div>
          <div>
            <div className="login-stat-value">{stations.length}</div>
            <div className="login-stat-label">Stations</div>
          </div>
          <div>
            <div className="login-stat-value">{officers.length}</div>
            <div className="login-stat-label">Registered officers</div>
          </div>
        </div>
      </div>

      <div className="login-form-side">
        <div className="login-card">
          <h2>Sign in</h2>

          {error && <div className="error-banner">{error}</div>}

          <form onSubmit={handleSubmit}>
            <div className="field">
              <label htmlFor="loginId">Login ID</label>
              <input
                id="loginId"
                type="text"
                placeholder="e.g. rmenon"
                value={loginId}
                onChange={(e) => setLoginId(e.target.value)}
                autoComplete="off"
              />
            </div>

            <div className="field">
              <label htmlFor="password">Password</label>
              <input
                id="password"
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>

            <button type="submit" className="btn-primary">
              Sign in
            </button>
          </form>

          <button
            type="button"
            className="creds-toggle"
            onClick={() => setShowCreds((v) => !v)}
          >
            {showCreds ? 'Hide demo credentials' : 'Show demo credentials'}
          </button>

          {showCreds && (
            <div className="creds-panel">
              <div className="creds-row head">
                <span>Officer</span>
                <span>Login ID</span>
                <span>Password</span>
              </div>
              {credentials.map((c) => (
                <div className="creds-row" key={c.officer_id}>
                  <span>{c.name}</span>
                  <span>{c.login_id}</span>
                  <span>{c.password}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
