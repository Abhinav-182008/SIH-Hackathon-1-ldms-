import React, { useState, useMemo } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext.jsx'
import TopBar from '../components/TopBar.jsx'
import cases from '../data/cases_manifest.json'
import officers from '../data/officers.json'
import stations from '../data/stations.json'
import { isEligible } from '../utils/access.js'
import './SearchRecord.css'

const STOPWORDS = new Set([
  'a','an','the','of','in','on','at','is','are','was','were','mentioning',
  'get','me','all','any','that','has','have','been','reported','show',
  'find','case','cases','with','for','and','to','who','where','every',
  'record','records','list','give','please','about',
])

const EXAMPLE_QUERIES = [
  'red car',
  'cases at MG Road station',
  'assigned to Fathima Beevi',
  'cybercrime',
  'missing person',
]

function searchableText(c) {
  return [
    c.case_id,
    c.crime_type,
    c.section_act,
    c.status,
    c.station_name,
    c.suspect_name,
    c.incident_location,
    c.investigating_officer,
    c.assisting_officer,
  ]
    .join(' ')
    .toLowerCase()
}

function reviewerFor(caseItem) {
  const station = stations.find((s) => s.name === caseItem.station_name)
  return station ? station.officer_in_charge : 'the district SP'
}

export default function SearchRecord() {
  const { officer } = useAuth()
  const navigate = useNavigate()
  const [query, setQuery] = useState('')
  const [expanded, setExpanded] = useState(null)
  const [requested, setRequested] = useState({})

  const results = useMemo(() => {
    if (!query.trim()) return []
    const tokens = query
      .toLowerCase()
      .split(/\s+/)
      .filter((t) => t.length > 2 && !STOPWORDS.has(t))

    if (tokens.length === 0) return []

    return cases
      .map((c) => {
        const text = searchableText(c)
        const score = tokens.reduce(
          (acc, t) => acc + (text.includes(t) ? 1 : 0),
          0
        )
        return { c, score }
      })
      .filter((r) => r.score > 0)
      .sort((a, b) => b.score - a.score)
      .map((r) => r.c)
  }, [query])

  function handleRequest(caseId) {
    setRequested((prev) => ({ ...prev, [caseId]: true }))
  }

  return (
    <div>
      <TopBar />
      <div className="search-wrap">
        <div className="page-header">
          <h1>Search Record</h1>
          <p>
            Ask about a case in plain language. Results come from indexed
            case metadata — opening the original file still checks your
            clearance.
          </p>
        </div>

        <div className="search-box">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
            <circle cx="11" cy="11" r="7" stroke="currentColor" strokeWidth="1.6"/>
            <path d="m20 20-3.5-3.5" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"/>
          </svg>
          <input
            placeholder="e.g. get me every case mentioning a red car"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>

        <div className="chip-row">
          {EXAMPLE_QUERIES.map((q) => (
            <button key={q} className="chip" onClick={() => setQuery(q)}>
              {q}
            </button>
          ))}
        </div>

        {query.trim() && (
          <div className="results-count">
            {results.length} matching case{results.length === 1 ? '' : 's'}
          </div>
        )}

        {query.trim() && results.length === 0 && (
          <div className="empty-state">
            No cases match that query. Try a different term or one of the
            examples above.
          </div>
        )}

        {results.map((c) => {
          const eligible = isEligible(officer, c)
          const isOpen = expanded === c.case_id
          const alreadyRequested = requested[c.case_id]

          return (
            <div className="result-card" key={c.case_id}>
              <div className="result-top">
                <div>
                  <div className="result-case-id mono">{c.case_id}</div>
                  <div className="result-title">{c.crime_type}</div>
                  <div className="result-meta">
                    <span>{c.station_name}</span>
                    <span>·</span>
                    <span>{c.incident_date}</span>
                    <span>·</span>
                    <span className={`badge ${c.status === 'Charge Sheet Filed' ? 'badge-teal' : 'badge-slate'}`}>
                      {c.status}
                    </span>
                  </div>
                </div>

                <div className="result-actions">
                  {eligible ? (
                    <button
                      className="btn-small view"
                      onClick={() =>
                        setExpanded(isOpen ? null : c.case_id)
                      }
                    >
                      {isOpen ? 'Hide details' : 'View case'}
                    </button>
                  ) : alreadyRequested ? (
                    <span className="request-sent">
                      Request sent to {reviewerFor(c)}
                    </span>
                  ) : (
                    <button
                      className="btn-small request"
                      onClick={() => handleRequest(c.case_id)}
                    >
                      Request access
                    </button>
                  )}
                </div>
              </div>

              {isOpen && eligible && (
                <div className="detail-panel">
                  <div className="item">
                    <span>Suspect / party</span>
                    <span>{c.suspect_name}</span>
                  </div>
                  <div className="item">
                    <span>Section / Act</span>
                    <span>{c.section_act}</span>
                  </div>
                  <div className="item">
                    <span>Incident location</span>
                    <span>{c.incident_location}</span>
                  </div>
                  <div className="item">
                    <span>Investigating officer</span>
                    <span>{c.investigating_officer}</span>
                  </div>
                  <div className="item full">
                    <span>Required documents on file</span>
                    <span>{c.documents.join(', ')}</span>
                  </div>
                  {c.external_assignments?.length > 0 && (
                    <div className="item full">
                      <span>Externally assigned</span>
                      <span>{c.external_assignments.join('; ')}</span>
                    </div>
                  )}
                </div>
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}
