import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext.jsx'
import TopBar from '../components/TopBar.jsx'
import cases from '../data/cases_manifest.json'
import './AddRecord.css'

const FILE_TYPES = [
  'FIR',
  'Investigation Report',
  'Witness Statement',
  'Charge Sheet',
  'Forensic Report',
  'Evidence List',
]

export default function AddRecord() {
  const { officer } = useAuth()
  const navigate = useNavigate()

  const [mode, setMode] = useState(cases.length ? 'existing' : 'new') // 'existing' | 'new'
  const [caseId, setCaseId] = useState(cases.length ? cases[0].case_id : '')
  const [newCaseId, setNewCaseId] = useState('')
  const [crimeType, setCrimeType] = useState('')
  const [fileType, setFileType] = useState(FILE_TYPES[0])
  const [suspectName, setSuspectName] = useState('')
  const [section, setSection] = useState('')
  const [location, setLocation] = useState('')
  const [notes, setNotes] = useState('')
  const [file, setFile] = useState(null)
  const [dragging, setDragging] = useState(false)
  const [submitted, setSubmitted] = useState(null)

  function handleFile(f) {
    if (f) setFile(f)
  }

  function handleSubmit(e) {
    e.preventDefault()
    const finalCaseId = mode === 'existing' ? caseId : newCaseId.trim()
    if (!finalCaseId || !file) return

    const docId =
      'DOC-' + Math.random().toString(36).slice(2, 8).toUpperCase()
    const timestamp = new Date().toLocaleString()

    setSubmitted({
      docId,
      caseId: finalCaseId,
      fileName: file.name,
      timestamp,
    })
  }

  if (submitted) {
    return (
      <div>
        <TopBar />
        <div className="page-wrap">
          <button className="back-link" onClick={() => navigate('/dashboard')}>
            ← Back to dashboard
          </button>
          <div className="success-panel">
            <h4>Record saved and encrypted</h4>
            <div className="doc-id">
              Document ID: {submitted.docId} · Case {submitted.caseId}
            </div>
            <div className="audit-preview">
              <div className="row">
                <span>OCR text extracted</span>
                <span>{submitted.fileName}</span>
              </div>
              <div className="row">
                <span>Metadata indexed for search</span>
                <span>✓</span>
              </div>
              <div className="row">
                <span>Original file encrypted (AES-256)</span>
                <span>✓</span>
              </div>
              <div className="row">
                <span>Logged by</span>
                <span>{officer.name} · {submitted.timestamp}</span>
              </div>
            </div>
          </div>
          <div style={{ marginTop: 20, display: 'flex', gap: 12 }}>
            <button
              className="mode-btn active"
              style={{ flex: 'none', padding: '9px 18px' }}
              onClick={() => setSubmitted(null)}
            >
              Add another
            </button>
            <button
              className="mode-btn"
              style={{ flex: 'none', padding: '9px 18px' }}
              onClick={() => navigate('/search-record')}
            >
              Go to search
            </button>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div>
      <TopBar />
      <div className="page-wrap">
        <button className="back-link" onClick={() => navigate('/dashboard')}>
          ← Back to dashboard
        </button>
        <div className="page-header">
          <h1>Add Record</h1>
          <p>
            Attach a document to a case. The original file will be encrypted
            and moved to secure storage — only the details below stay
            searchable.
          </p>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="form-section">
            <h4>Case</h4>
            <div className="case-mode-toggle">
              <button
                type="button"
                className={`mode-btn ${mode === 'existing' ? 'active' : ''}`}
                onClick={() => setMode('existing')}
                disabled={cases.length === 0}
              >
                Use existing case
              </button>
              <button
                type="button"
                className={`mode-btn ${mode === 'new' ? 'active' : ''}`}
                onClick={() => setMode('new')}
              >
                Create new case
              </button>
            </div>

            {mode === 'existing' ? (
              <div className="field" style={{ marginBottom: 0 }}>
                <label>Case ID</label>
                <select value={caseId} onChange={(e) => setCaseId(e.target.value)}>
                  {cases.map((c) => (
                    <option key={c.case_id} value={c.case_id}>
                      {c.case_id} — {c.crime_type} ({c.station_name})
                    </option>
                  ))}
                </select>
              </div>
            ) : (
              <div className="row-2">
                <div className="field" style={{ marginBottom: 0 }}>
                  <label>New Case ID</label>
                  <input
                    placeholder="e.g. 2024-CR-122"
                    value={newCaseId}
                    onChange={(e) => setNewCaseId(e.target.value)}
                  />
                </div>
                <div className="field" style={{ marginBottom: 0 }}>
                  <label>Crime Type</label>
                  <input
                    placeholder="e.g. Burglary"
                    value={crimeType}
                    onChange={(e) => setCrimeType(e.target.value)}
                  />
                </div>
              </div>
            )}
          </div>

          <div className="form-section">
            <h4>Document</h4>
            <div className="field">
              <label>Document type</label>
              <select value={fileType} onChange={(e) => setFileType(e.target.value)}>
                {FILE_TYPES.map((t) => (
                  <option key={t}>{t}</option>
                ))}
              </select>
            </div>

            <div
              className={`dropzone ${dragging ? 'dragging' : ''}`}
              onDragOver={(e) => {
                e.preventDefault()
                setDragging(true)
              }}
              onDragLeave={() => setDragging(false)}
              onDrop={(e) => {
                e.preventDefault()
                setDragging(false)
                handleFile(e.dataTransfer.files[0])
              }}
              onClick={() => document.getElementById('file-input').click()}
            >
              <div className="mono" style={{ fontSize: 22 }}>+</div>
              <p>Drag a file here, or click to browse</p>
              <div className="file-hint">PDF, JPG, PNG — any format runs through OCR</div>
              <input
                id="file-input"
                type="file"
                style={{ display: 'none' }}
                onChange={(e) => handleFile(e.target.files[0])}
              />
            </div>

            {file && (
              <div className="selected-file" style={{ marginTop: 12 }}>
                <span>{file.name}</span>
                <button type="button" onClick={() => setFile(null)}>
                  Remove
                </button>
              </div>
            )}
          </div>

          <div className="form-section">
            <h4>Extracted details (edit if OCR missed anything)</h4>
            <div className="row-2">
              <div className="field">
                <label>Suspect / party name</label>
                <input
                  placeholder="e.g. Rahul Menon"
                  value={suspectName}
                  onChange={(e) => setSuspectName(e.target.value)}
                />
              </div>
              <div className="field">
                <label>Section / Act</label>
                <input
                  placeholder="e.g. Section 303 BNS"
                  value={section}
                  onChange={(e) => setSection(e.target.value)}
                />
              </div>
            </div>
            <div className="field">
              <label>Incident location</label>
              <input
                placeholder="e.g. MG Road, near City Mall"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
              />
            </div>
            <div className="field" style={{ marginBottom: 0 }}>
              <label>Notes / statement summary</label>
              <textarea
                rows={4}
                style={{
                  width: '100%',
                  background: 'var(--bg-panel)',
                  border: '1px solid var(--border)',
                  borderRadius: 'var(--radius-sm)',
                  padding: '10px 12px',
                  color: 'var(--text-primary)',
                  fontSize: 14,
                  resize: 'vertical',
                }}
                placeholder="Short summary of what this document contains..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
              />
            </div>
          </div>

          <button type="submit" className="btn-primary btn-full">
            Save record
          </button>
        </form>
      </div>
    </div>
  )
}
