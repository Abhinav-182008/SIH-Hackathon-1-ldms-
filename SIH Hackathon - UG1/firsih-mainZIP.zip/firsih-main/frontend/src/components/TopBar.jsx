import React from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext.jsx'
import { accessLevelLabel } from '../utils/access.js'
import './TopBar.css'

function initials(name) {
  return name
    .split(' ')
    .map((p) => p[0])
    .slice(0, 2)
    .join('')
    .toUpperCase()
}

export default function TopBar() {
  const { officer, logout } = useAuth()
  const navigate = useNavigate()

  if (!officer) return null

  return (
    <div className="topbar">
      <div className="topbar-left" onClick={() => navigate('/dashboard')}>
        <div className="topbar-glyph">CV</div>
        <div className="topbar-name">CaseVault</div>
      </div>

      <div className="topbar-right">
        <span
          className="mono"
          style={{ fontSize: 11, color: 'var(--text-muted)' }}
          title={accessLevelLabel(officer.access_level)}
        >
          {accessLevelLabel(officer.access_level)}
        </span>
        <div className="officer-chip">
          <div className="officer-avatar">{initials(officer.name)}</div>
          <div className="officer-chip-text">
            <span className="officer-chip-name">{officer.name}</span>
            <span className="officer-chip-rank">{officer.rank}</span>
          </div>
        </div>
        <button
          className="logout-btn"
          onClick={() => {
            logout()
            navigate('/')
          }}
        >
          Sign out
        </button>
      </div>
    </div>
  )
}
