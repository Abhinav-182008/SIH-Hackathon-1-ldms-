import React, { createContext, useContext, useState } from 'react'
import officers from '../data/officers.json'
import credentials from '../data/credentials.json'
import stations from '../data/stations.json'

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [officer, setOfficer] = useState(null)
  const [error, setError] = useState('')

  function login(loginId, password) {
    const cred = credentials.find(
      (c) => c.login_id.toLowerCase() === loginId.trim().toLowerCase()
    )
    if (!cred || cred.password !== password) {
      setError('Login ID or password is incorrect.')
      return false
    }
    const record = officers.find((o) => o.officer_id === cred.officer_id)
    const station = stations.find(
      (s) => s.name === record.station || s.station_id === record.station
    )
    setError('')
    setOfficer({ ...record, stationDetail: station || null })
    return true
  }

  function logout() {
    setOfficer(null)
  }

  return (
    <AuthContext.Provider value={{ officer, login, logout, error, setError }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  return useContext(AuthContext)
}
