import React from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import { AuthProvider, useAuth } from './context/AuthContext.jsx'
import Login from './pages/Login.jsx'
import Dashboard from './pages/Dashboard.jsx'
import AddRecord from './pages/AddRecord.jsx'
import SearchRecord from './pages/SearchRecord.jsx'

function RequireAuth({ children }) {
  const { officer } = useAuth()
  if (!officer) return <Navigate to="/" replace />
  return children
}

function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<Login />} />
      <Route
        path="/dashboard"
        element={
          <RequireAuth>
            <Dashboard />
          </RequireAuth>
        }
      />
      <Route
        path="/add-record"
        element={
          <RequireAuth>
            <AddRecord />
          </RequireAuth>
        }
      />
      <Route
        path="/search-record"
        element={
          <RequireAuth>
            <SearchRecord />
          </RequireAuth>
        }
      />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}

export default function App() {
  return (
    <AuthProvider>
      <AppRoutes />
    </AuthProvider>
  )
}
