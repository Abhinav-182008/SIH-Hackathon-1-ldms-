# CaseVault — Frontend Prototype

A React + Vite prototype for the secure case file system: sign in as any
officer, then Add Record or Search Record.

This is a **frontend-only** prototype — there is no backend yet. Login,
encryption, and access control are all simulated in the browser using the
bundled fake dataset, so you can demo the flow end-to-end without setting up
a server. It's built to slot in cleanly once the real backend (Supabase +
encryption + OCR + AI search) is ready — the data shapes already match.

## Run it locally

```bash
npm install
npm run dev
```

Then open the local URL Vite prints (usually `http://localhost:5173`).

## Signing in

On the login screen, pick any officer from the dropdown, then use their
login ID and password below (or click "Show demo credentials" on the
login screen itself — it lists all of these live).

| Officer | Rank | Login ID | Password |
|---|---|---|---|
| Anil Kumar | Superintendent of Police (Level 5) | akumar | Kochi@001 |
| Priya Nair | Inspector, MG Road PS (Level 4) | pnair | Kochi@002 |
| Thomas Varghese | Inspector, Central PS (Level 4) | tvarghese | Kochi@003 |
| Rahul Menon | Sub-Inspector, MG Road PS (Level 3) | rmenon | Kochi@004 |
| Fathima Beevi | Sub-Inspector, Central PS (Level 3) | fbeevi | Kochi@005 |
| Arjun Pillai | Sub-Inspector, Coastal PS (Level 3) | apillai | Kochi@006 |
| Suresh Babu | Head Constable, MG Road PS (Level 2) | sbabu | Kochi@007 |
| Vishnu Prasad | Constable, MG Road PS (Level 1) | vprasad | Kochi@010 |
| Justice Meera Krishnan | District Judge (external) | jkrishnan | Kochi@EXT001 |
| Dr. Sanjay Iyer | Forensic Expert (external) | diyer | Kochi@EXT002 |

Full list of all 19 officers is in `src/data/credentials.json`.

**Good accounts to demo with:**
- **Anil Kumar (Level 5)** — sees every case, every "View case" button works
- **Rahul Menon (Level 3)** — only sees full details for cases he's investigating; try searching for a case at a different station to see the "Request access" button appear instead
- **Vishnu Prasad (Level 1)** — very limited direct access, good for showing the escalation flow

## What's simulated vs. real

| Feature | This prototype | Planned real version |
|---|---|---|
| Login | Checks against a hardcoded credentials list | Supabase Auth with hashed passwords |
| Access control | Client-side rule based on officer level + case assignment | Same rules, enforced server-side |
| Search | Keyword match over the bundled JSON case metadata | Embeddings + pgvector + LLM-synthesized answers |
| File encryption | Not wired up yet — "Add Record" shows the flow but doesn't touch real files | AES-256 per file, key wrapped per recipient (see the technical build guide) |
| Access requests | Shows a "Request sent" message, not persisted anywhere | Written to an `access_requests` table, visible to the approving officer |
| Audit log | Not implemented in this UI | Hash-chained `audit_log` table, server-only visibility |

## Project structure

```
src/
  data/                  fake officers, stations, cases, and demo credentials
  context/AuthContext.jsx  login state
  utils/access.js        the 5-level eligibility rules
  pages/                 Login, Dashboard, AddRecord, SearchRecord
  components/TopBar.jsx  shared header showing the signed-in officer
```

## Try this demo query on the Search Record page

Search **"red car"** — it should surface both **2024-CR-104** (robbery) and
**2024-CR-105** (hit and run), which share a partial vehicle plate. This is
the same cross-case pattern the real AI search layer is meant to catch.
